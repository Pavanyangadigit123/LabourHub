package com.example.mca.labourPlatform.util;

import org.springframework.beans.BeanUtils;

import com.example.mca.labourPlatform.dto.UsersDto;
import com.example.mca.labourPlatform.model.Users;

public class UsersUtil {
	public static UsersDto convertUsersEntityToDto(Users users)
	{
		UsersDto dto=new UsersDto();
		BeanUtils.copyProperties(users, dto);
		return dto;
	}
	
	public static Users convertUsersDtoToEntity(UsersDto dto)
	{
		Users users=new Users();
		BeanUtils.copyProperties(dto,users);
		
		return users;
	}

}
