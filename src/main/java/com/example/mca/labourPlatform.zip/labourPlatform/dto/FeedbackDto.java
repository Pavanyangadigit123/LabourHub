//package com.example.mca.labourPlatform.dto;
//
//import java.sql.Date;
//
//public class FeedbackDto {
//	private Integer feedbackId;
//	private Date feedbackDate;
//	private String feedbackDescription;
//	private Integer rating;
//	public Integer getFeedbackId() {
//		return feedbackId;
//	}
//	public void setFeedbackId(Integer feedbackId) {
//		this.feedbackId = feedbackId;
//	}
//	public Date getFeedbackDate() {
//		return feedbackDate;
//	}
//	public void setFeedbackDate(Date feedbackDate) {
//		this.feedbackDate = feedbackDate;
//	}
//	public String getFeedbackDescription() {
//		return feedbackDescription;
//	}
//	public void setFeedbackDescription(String feedbackDescription) {
//		this.feedbackDescription = feedbackDescription;
//	}
//	public Integer getRating() {
//		return rating;
//	}
//	public void setRating(Integer rating) {
//		this.rating = rating;
//	}
//
//}
