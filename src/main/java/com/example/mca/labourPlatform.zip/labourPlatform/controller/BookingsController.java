package com.example.mca.labourPlatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mca.labourPlatform.dto.BookingsDto;
import com.example.mca.labourPlatform.model.Bookings;
import com.example.mca.labourPlatform.service.BookingsService;
import com.example.mca.labourPlatform.service.LabourerProfileService;
import com.example.mca.labourPlatform.service.UsersService;

@RestController
@RequestMapping("/api")
public class BookingsController {
	
		@Autowired
	    private UsersService usersService ;

	    @Autowired
	    private LabourerProfileService labourerProfileService;

	    @Autowired
	    private BookingsService bookingsService;

	    // Get all bookings for a specific user
//	    @GetMapping("/users/{id}/bookings")
//	    public ResponseEntity<List<Booking>> getBookingsByUserId(@PathVariable(value = "id") Long userId) {
//	        List<Booking> bookings = bookingRepository.findByUserId(userId);
//	        if (bookings.isEmpty()) {
//	            return ResponseEntity.notFound().build();
//	        }
//	        return ResponseEntity.ok().body(bookings);
//	    }

	    // Create a new booking
	    @PostMapping("/bookings/{userId}/{labourerId}")
	    public ResponseEntity<BookingsDto> createBookin(@PathVariable(name="userId")Integer userId,
	    												@PathVariable(name="labourerId")Integer labourerId,
	    												@RequestBody Bookings booking) {
	       
	    	return bookingsService.createBooking(booking,userId,labourerId);
	    }
	}



