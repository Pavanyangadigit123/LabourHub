//package com.example.mca.labourPlatform.model;
//
//import java.sql.Date;
//
//import jakarta.persistence.Column;
//
//public class Feedback {
//	
//	@Column(name="feedback_id")
//	private Integer feedbackId;
//	
//	@Column(name="feedback_date")
//	private Date feedbackDate;
//	
//	@Column(name="feedback_description")
//	private String feedbackDescription;
//	
//	@Column(name="rating")
//	private Integer rating;
//
//	public Integer getFeedbackId() {
//		return feedbackId;
//	}
//
//	public void setFeedbackId(Integer feedbackId) {
//		this.feedbackId = feedbackId;
//	}
//
//	public Date getFeedbackDate() {
//		return feedbackDate;
//	}
//
//	public void setFeedbackDate(Date feedbackDate) {
//		this.feedbackDate = feedbackDate;
//	}
//
//	public String getFeedbackDescription() {
//		return feedbackDescription;
//	}
//
//	public void setFeedbackDescription(String feedbackDescription) {
//		this.feedbackDescription = feedbackDescription;
//	}
//
//	public Integer getRating() {
//		return rating;
//	}
//
//	public void setRating(Integer rating) {
//		this.rating = rating;
//	}
//
//	@Override
//	public String toString() {
//		return "Feedback [feedbackId=" + feedbackId + ", feedbackDate=" + feedbackDate + ", feedbackDescription="
//				+ feedbackDescription + ", rating=" + rating + "]";
//	}
//	
//	
//	
//	
//
//}
