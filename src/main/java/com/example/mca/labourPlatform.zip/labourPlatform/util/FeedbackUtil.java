//package com.example.mca.labourPlatform.util;
//
//import org.springframework.beans.BeanUtils;
//
//import com.example.mca.labourPlatform.dto.FeedbackDto;
//import com.example.mca.labourPlatform.model.Feedback;
//
//
//
//public class FeedbackUtil {
//	public static FeedbackDto covertFeedbackEntityToDto(Feedback feedback)
//	{
//		FeedbackDto dto=new FeedbackDto();
//		BeanUtils.copyProperties(feedback, dto);
//		return dto;
//	}
//	
//	public static Feedback covertUsersDtoToEntity(FeedbackDto dto)
//	{
//		Feedback feedback=new Feedback();
//		BeanUtils.copyProperties(dto,feedback);
//		return feedback;
//	}
//
//}
