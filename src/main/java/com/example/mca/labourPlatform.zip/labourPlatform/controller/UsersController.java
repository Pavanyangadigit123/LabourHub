package com.example.mca.labourPlatform.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mca.labourPlatform.dto.UsersDto;
import com.example.mca.labourPlatform.service.UsersService;

@RestController
@RequestMapping(path="api/v1/user")
public class UsersController {
	
	private final UsersService usersService;
	
	public UsersController (UsersService usersService)
	{
		this.usersService=usersService;
	}
	
	@GetMapping
	public List<UsersDto> getUsers()
	{
		return usersService.getUsers();
	}
	
	@PostMapping
	public void registerNewUsers(@RequestBody UsersDto dto)
	{
		
		usersService.createUser(dto);
		
	}
	
	@PutMapping("/id/{userId}")
	public UsersDto updateUser(
			@PathVariable(name="userId") Integer userId,
			@RequestBody UsersDto usersDto
			)
	{
		return usersService.updateUser(userId,usersDto);
	}
	
	@DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Integer id) {
        usersService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
	

}
