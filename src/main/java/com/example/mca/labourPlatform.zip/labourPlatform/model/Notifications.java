//package com.example.mca.labourPlatform.model;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//
//@Entity
//@Table
//public class Notifications {
//	
//	@Id
//    @GeneratedValue
//    @Column(name="notification_id")
//	private Integer notificationId;
//	private String description;
//	private boolean is_read;
//	public Integer getNotificationId() {
//		return notificationId;
//	}
//	public void setNotificationId(Integer notificationId) {
//		this.notificationId = notificationId;
//	}
//	public String getDescription() {
//		return description;
//	}
//	public void setDescription(String description) {
//		this.description = description;
//	}
//	public boolean isIs_read() {
//		return is_read;
//	}
//	public void setIs_read(boolean is_read) {
//		this.is_read = is_read;
//	}
//	@Override
//	public String toString() {
//		return "Notifications [notificationId=" + notificationId + ", description=" + description + ", is_read="
//				+ is_read + "]";
//	}
//	
//	 
//	  
//
//	
//	
//
//}
