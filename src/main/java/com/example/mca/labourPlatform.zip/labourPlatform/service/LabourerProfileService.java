package com.example.mca.labourPlatform.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mca.labourPlatform.dao.LabourerProfileRepository;
import com.example.mca.labourPlatform.dto.LabourerProfileDto;
import com.example.mca.labourPlatform.dto.UsersDto;
import com.example.mca.labourPlatform.model.LabourerProfile;
import com.example.mca.labourPlatform.model.Users;
import com.example.mca.labourPlatform.util.LabourerProfileUtil;

import jakarta.transaction.Transactional;

@Service
public class LabourerProfileService {

	@Autowired
	private UsersService usersService;

	@Autowired
	private LabourerProfileRepository labourerProfileRepository;

	public void createLabourProfile(UsersDto userDto) {

		Users user = usersService.createUser(userDto);
		LabourerProfile labourerProfile = LabourerProfileUtil
				.convertLabourerProfileDtoToEntity(userDto.getLabourerProfileDto());
		labourerProfile.setUser(user);
		labourerProfileRepository.save(labourerProfile);

	}
	
	@Transactional
	public LabourerProfileDto updateLabour(Integer labourerId, LabourerProfileDto labourerProfileDto) {

		LabourerProfile existingLabour = labourerProfileRepository.findById(labourerId)
				.orElseThrow(() -> new IllegalStateException("Student with id " + labourerId + " doesn't exists"));

		// Update Daily wages

		if (labourerProfileDto.getDailyWages() != null &&

				!Objects.equals(labourerProfileDto.getDailyWages(), existingLabour.getDailyWages()))

		{

			existingLabour.setDailyWages(labourerProfileDto.getDailyWages());

		}

		// Update Availability
		if (labourerProfileDto.isAvailability() != null &&

				!Objects.equals(labourerProfileDto.isAvailability(), existingLabour.isAvailability()))

		{

			existingLabour.setAvailability(labourerProfileDto.isAvailability());

		}
		return LabourerProfileUtil.convertLabourerProfileEntityToDto(existingLabour);

	}

	public void deletelabour(Integer id) {
		labourerProfileRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
	     
		labourerProfileRepository.deleteById(id);
		
	}
}
