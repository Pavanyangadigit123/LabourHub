package com.example.mca.labourPlatform.service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.example.mca.labourPlatform.dao.UsersRepository;
import com.example.mca.labourPlatform.dto.UsersDto;
import com.example.mca.labourPlatform.model.Users;
import com.example.mca.labourPlatform.util.UsersUtil;

import jakarta.transaction.Transactional;

@Service
public class UsersService {
	
	@Autowired
	private  UsersRepository usersRepository;

	
	public List<UsersDto> getUsers(){
		List<UsersDto> listOfDtos=usersRepository.
				findAll().stream()
				.map(UsersUtil::convertUsersEntityToDto)
				.collect(Collectors.toList());
		return listOfDtos;
	}
	
	public Users createUser(UsersDto dto)
	{
		Users users=UsersUtil.convertUsersDtoToEntity(dto);
		try {
			usersRepository.save(users);
		}
		catch(DataIntegrityViolationException exception)
		{
			throw new DataIntegrityViolationException(/* "user already exsit"+ */exception.getLocalizedMessage());
		}
		return users;
		
	}
	
	@Transactional
	public UsersDto updateUser(Integer userId, UsersDto usersDto) {
		Users existinguser = usersRepository.findById(userId)
				.orElseThrow(() -> new IllegalStateException("Student with id " + userId + " doesn't exists"));

		// Update email
		if (usersDto.getEmail() != null &&
				!Objects.equals(usersDto.getEmail(), existinguser.getEmail()))
		{
			existinguser.setEmail(usersDto.getEmail());
		}

		// Update FirstName
		if (usersDto.getFirstName() != null &&
				!Objects.equals(usersDto.getFirstName(),existinguser.getFirstName()))
		{
			existinguser.setFirstName(usersDto.getFirstName());
		}
		return UsersUtil.convertUsersEntityToDto(existinguser);
	}

	public void deleteUser(Integer id) {
		 usersRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
     
       usersRepository.deleteById(id);
   }
		
	}

	
	


