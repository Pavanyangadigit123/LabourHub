package com.example.mca.labourPlatform.util;

import org.springframework.beans.BeanUtils;

import com.example.mca.labourPlatform.dto.BookingsDto;
import com.example.mca.labourPlatform.model.Bookings;

public class BookingsUtil {
	public static BookingsDto convertBookingsEntityToDto(Bookings bookings)
	{
		BookingsDto dto=new BookingsDto();
		BeanUtils.copyProperties(bookings, dto);
		return dto;
	}
	
	public static Bookings convertBookingsDtoToEntity(BookingsDto dto)
	{
		Bookings bookings=new Bookings();
		BeanUtils.copyProperties(dto,bookings);
		return bookings;
	}
}
