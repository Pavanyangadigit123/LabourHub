package com.example.mca.labourPlatform.service;


import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.mca.labourPlatform.dao.BookingsRepository;
import com.example.mca.labourPlatform.dao.LabourerProfileRepository;
import com.example.mca.labourPlatform.dao.UsersRepository;
import com.example.mca.labourPlatform.dto.BookingsDto;
import com.example.mca.labourPlatform.model.Bookings;
import com.example.mca.labourPlatform.model.LabourerProfile;
import com.example.mca.labourPlatform.model.Users;
import com.example.mca.labourPlatform.util.BookingsUtil;

@Service
public class BookingsService {
	
	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LabourerProfileRepository labourerProfileRepository;
	
	@Autowired
	private BookingsRepository bookingsRepository;
	
	
	 public ResponseEntity<BookingsDto> createBooking(Bookings booking,Integer userId,Integer labourerId) {
	        Users user = usersRepository.findById(userId).orElse(null);
	        LabourerProfile labour = labourerProfileRepository.findById(labourerId).orElse(null);
	        if (user == null || labour == null) {
	            return ResponseEntity.notFound().build();
	        }
	        booking.setUser(user);
	        booking.setLabourerProfile(labour);
	        booking.setBookingDate(LocalDateTime.now());
	        booking.setStartTime(LocalDateTime.now());
	        booking.setEndTime(LocalDateTime.now());
	        System.out.println(booking.getBookingDate());
	        Bookings savedBooking = bookingsRepository.save(booking);
	        return ResponseEntity.ok().body(BookingsUtil.convertBookingsEntityToDto(savedBooking));
	    }

}
