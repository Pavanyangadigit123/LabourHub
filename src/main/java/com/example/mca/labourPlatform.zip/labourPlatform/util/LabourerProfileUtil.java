package com.example.mca.labourPlatform.util;

import org.springframework.beans.BeanUtils;

import com.example.mca.labourPlatform.dto.LabourerProfileDto;
import com.example.mca.labourPlatform.model.LabourerProfile;

public class LabourerProfileUtil {
	public static LabourerProfileDto convertLabourerProfileEntityToDto(LabourerProfile labourerProfile)
	{
		LabourerProfileDto dto=new LabourerProfileDto();
		BeanUtils.copyProperties(labourerProfile, dto);
		return dto;
	}
	
	public static LabourerProfile convertLabourerProfileDtoToEntity(LabourerProfileDto dto)
	{
		LabourerProfile labourerProfile=new LabourerProfile();
		BeanUtils.copyProperties(dto,labourerProfile);
		return labourerProfile;
	}

}
