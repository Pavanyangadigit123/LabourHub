package com.example.mca.labourPlatform.dto;

public class LabourerProfileDto {
	
	private Integer labourerId;
	private Double dailyWages;
	private Boolean availability;
	public Integer getLabourerId() {
		return labourerId;
	}
	public void setLabourerId(Integer labourerId) {
		this.labourerId = labourerId;
	}
	public Double getDailyWages() {
		return dailyWages;
	}
	public void setDailyWages(Double dailyWages) {
		this.dailyWages = dailyWages;
	}
	public Boolean isAvailability() {
		return availability;
	}
	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}
	

}
