package com.example.mca.labourPlatform.dto;

public class UsersDto {
	private Integer userId;
	private String email;
	private String area;
	private String phoneNumber;
	private String country;
	private String state;
	private String city;
	private String zipcode;
	private String profilePic;
	private String firstName;
	private String lastName;
	
	LabourerProfileDto labourerProfileDto;
	
	//AdmiProdto
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer user_id) {
		this.userId = user_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phone_number) {
		this.phoneNumber = phone_number;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public LabourerProfileDto getLabourerProfileDto() {
		return labourerProfileDto;
	}
	public void setLabourerProfileDto(LabourerProfileDto labourerProfileDto) {
		this.labourerProfileDto = labourerProfileDto;
	}
	
	

}
