package com.example.mca.labourPlatform.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class LabourerProfile {
	@Id
	@GeneratedValue
	@Column(name="labourer_id")
	private Integer labourerId;
	
	@Column(name="daily_wages")
	private Double dailyWages;
	
	private Boolean availability;
	
	@OneToOne()
	@JoinColumn(name = "user_id", referencedColumnName = "user_id")
	private Users user;
	
	@OneToMany(mappedBy = "labourerProfile",cascade = CascadeType.PERSIST,orphanRemoval = true)
    private List<Bookings> bookings;

	public Integer getLabourerId() {
		return labourerId;
	}

	public void setLabourerId(Integer labourerId) {
		this.labourerId = labourerId;
	}

	public double getDailyWages() {
		return dailyWages;
	}

	public void setDailyWages(double dailyWages) {
		this.dailyWages = dailyWages;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "LabourerProfile [labourerId=" + labourerId + ", dailyWages=" + dailyWages + ", availability="
				+ availability + "]";
	}
	
	
	
	
	
	
	
	
	
	

}
