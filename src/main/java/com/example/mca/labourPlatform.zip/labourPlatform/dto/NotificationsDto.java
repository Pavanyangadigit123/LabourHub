//package com.example.mca.labourPlatform.dto;
//
//public class NotificationsDto {
//	private Integer notification_id;
//	private String description;
//	private boolean is_read;
//	
//	public Integer getNotification_id() {
//		return notification_id;
//	}
//	public void setNotification_id(Integer notification_id) {
//		this.notification_id = notification_id;
//	}
//	public String getDescription() {
//		return description;
//	}
//	public void setDescription(String description) {
//		this.description = description;
//	}
//	public boolean isIs_read() {
//		return is_read;
//	}
//	public void setIs_read(boolean is_read) {
//		this.is_read = is_read;
//	}
//
//}
