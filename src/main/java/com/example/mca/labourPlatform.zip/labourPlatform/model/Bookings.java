package com.example.mca.labourPlatform.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Bookings {
	
	@Id
	@GeneratedValue
	@Column(name="booking_id")
	private Integer bookingId;
	
	@Column(name="booking_date")
	private LocalDateTime bookingDate;

	@Column(name="start_time")
	private LocalDateTime startTime;
	
	@Column(name="end_time")
	private LocalDateTime endTime;
	
	@Column(name="booking_status")
	private String bookingStatus;
	
	@ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;

    @ManyToOne
    @JoinColumn(name = "labourer_id", referencedColumnName = "labourer_id", nullable = false)
    private LabourerProfile labourerProfile;
    
    public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public LabourerProfile getLabourerProfile() {
		return labourerProfile;
	}

	public void setLabourerProfile(LabourerProfile labourerProfile) {
		this.labourerProfile = labourerProfile;
	}

	
	

	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	
	public LocalDateTime getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	
	@Override
	public String toString() {
		return "Bookings [bookingId=" + bookingId + ", bookingDate=" + bookingDate + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", bookingStatus=" + bookingStatus + "]";
	}
	
	
}
