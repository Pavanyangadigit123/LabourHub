//package com.example.mca.labourPlatform.util;
//
//import org.springframework.beans.BeanUtils;
//
//import com.example.mca.labourPlatform.dto.NotificationsDto;
//import com.example.mca.labourPlatform.model.Notifications;
//
//public class NotificationsUtil {
//	public static NotificationsDto covertNotificationsEntityToDto(Notifications notifications)
//	{
//		NotificationsDto dto=new NotificationsDto();
//		BeanUtils.copyProperties(notifications,dto);
//		return dto;
//	}
//	
//	public static Notifications covertNotificationsDtoToEntity(NotificationsDto dto)
//	{
//		Notifications notifications=new Notifications();
//		BeanUtils.copyProperties(dto,notifications);
//		return notifications;
//	}
//}
