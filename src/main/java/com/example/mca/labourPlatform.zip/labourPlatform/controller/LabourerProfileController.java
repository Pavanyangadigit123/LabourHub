package com.example.mca.labourPlatform.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.mca.labourPlatform.dto.LabourerProfileDto;
import com.example.mca.labourPlatform.dto.UsersDto;
import com.example.mca.labourPlatform.service.LabourerProfileService;

@RestController
@RequestMapping("/labour")
public class LabourerProfileController {
	
	@Autowired
	private LabourerProfileService labourerProfileService;

	@PostMapping
	public void createLabour(@RequestBody UsersDto usersDto) {

		labourerProfileService.createLabourProfile(usersDto);		

	}
	
	@PutMapping("/id/{labourerId}")
	public LabourerProfileDto updateLabour(
			@PathVariable(name="labourerId") Integer labourerId,
			@RequestBody LabourerProfileDto labourerProfileDto
			)
	{
		return labourerProfileService.updateLabour(labourerId,labourerProfileDto);
	}
	
	@DeleteMapping("/{id}")
    public ResponseEntity<Void> deletelabour(@PathVariable Integer id) {
		labourerProfileService.deletelabour(id);
        return ResponseEntity.noContent().build();
    }
}
