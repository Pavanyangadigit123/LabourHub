package com.example.mca.labourPlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabourPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabourPlatformApplication.class, args);
	}

}
