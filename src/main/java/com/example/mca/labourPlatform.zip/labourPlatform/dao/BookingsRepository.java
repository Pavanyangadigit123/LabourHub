package com.example.mca.labourPlatform.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mca.labourPlatform.model.Bookings;

@Repository
public interface BookingsRepository extends JpaRepository<Bookings, Integer> {
//	List<Bookings> findByUserId(Integer userId);
}
